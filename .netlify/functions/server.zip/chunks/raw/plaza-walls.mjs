// ROLLUP_NO_REPLACE 
 const plazaWalls = "{\"parsed\":{\"_path\":\"/art/plaza-walls\",\"_dir\":\"art\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"Klienotype\",\"description\":\"\",\"slug\":\"plaza-walls\",\"category\":\"project\",\"order\":8,\"color\":\"#2200FF\",\"subtitle\":\"site-specific art\",\"roles\":[\"Design\",\"Production\"],\"year\":2024,\"clients\":[\"Oklahoma Mural Syndicate\"],\"featured_image\":\"/img/pw-hero.png\",\"previous\":\"/art/the-reader\",\"next\":\"/case-studies/perle-mesta\",\"images\":[\"/img/pw-01.png\",\"/img/pw-02.png\"],\"body\":{\"type\":\"root\",\"children\":[],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:art:plaza-walls.md\",\"_source\":\"content\",\"_file\":\"art/plaza-walls.md\",\"_stem\":\"art/plaza-walls\",\"_extension\":\"md\"},\"hash\":\"MCoVAKOH73\"}";

export { plazaWalls as default };
//# sourceMappingURL=plaza-walls.mjs.map
