// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/about\":[\"content:about.md\"],\"/\":[\"content:index.md\"],\"/art/mosaic\":[\"content:art:mosaic.md\"],\"/art/plaza-walls\":[\"content:art:plaza-walls.md\"],\"/art/the-reader\":[\"content:art:the-reader.md\"],\"/case-studies/ccb\":[\"content:case-studies:ccb.md\"],\"/case-studies/okcmoa\":[\"content:case-studies:okcmoa.md\"],\"/case-studies/perle-mesta\":[\"content:case-studies:perle-mesta.md\"],\"/projects/leaderhealth\":[\"content:projects:leaderhealth.md\"],\"/projects/rembaum-hanau\":[\"content:projects:rembaum-hanau.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
