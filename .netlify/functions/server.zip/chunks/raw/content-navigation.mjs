// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"About Content Version 3\",\"_path\":\"/about\"},{\"title\":\"Art\",\"_path\":\"/art\",\"children\":[{\"title\":\"Les Belles Choses\",\"_path\":\"/art/mosaic\"},{\"title\":\"Klienotype\",\"_path\":\"/art/plaza-walls\"},{\"title\":\"The Reader\",\"_path\":\"/art/the-reader\"}]},{\"title\":\"Case Studies\",\"_path\":\"/case-studies\",\"children\":[{\"title\":\"Chickasaw Community Bank\",\"_path\":\"/case-studies/ccb\"},{\"title\":\"Oklahoma City Museum of Art\",\"_path\":\"/case-studies/okcmoa\"},{\"title\":\"Perle Mesta\",\"_path\":\"/case-studies/perle-mesta\"}]},{\"title\":\"Welcome to Nuxt Content Starter\",\"_path\":\"/\"},{\"title\":\"Projects\",\"_path\":\"/projects\",\"children\":[{\"title\":\"LeaderHealth\",\"_path\":\"/projects/leaderhealth\"},{\"title\":\"Rembaum-Hanau\",\"_path\":\"/projects/rembaum-hanau\"}]}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
